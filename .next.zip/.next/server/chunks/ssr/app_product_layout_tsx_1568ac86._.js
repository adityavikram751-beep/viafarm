module.exports = [
"[project]/app/product/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const { jsxDEV: _jsxDEV } = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
{}{
    viewProduct && /*#__PURE__*/ _jsxDEV("div", {
        className: "fixed inset-0 flex items-center justify-center bg-black/50 z-50",
        children: /*#__PURE__*/ _jsxDEV("div", {
            className: "bg-white rounded-2xl shadow-lg w-full max-w-lg p-6 relative",
            children: [
                /*#__PURE__*/ _jsxDEV("button", {
                    onClick: ()=>setViewProduct(null),
                    className: "absolute top-3 right-3 text-gray-500 hover:text-black",
                    children: "✕"
                }, void 0, false, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 6,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "flex gap-4",
                    children: [
                        /*#__PURE__*/ _jsxDEV(Image, {
                            src: viewProduct.productImage,
                            alt: viewProduct.name,
                            width: 100,
                            height: 100,
                            className: "w-28 h-28 rounded-lg object-cover"
                        }, void 0, false, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 15,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("h2", {
                                            className: "text-xl font-semibold",
                                            children: viewProduct.name
                                        }, void 0, false, {
                                            fileName: "[project]/app/product/layout.tsx",
                                            lineNumber: 24,
                                            columnNumber: 13
                                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "flex items-center gap-1 bg-gray-100 border px-2 py-0.5 rounded-full text-xs font-medium",
                                            children: "⭐ 9.2"
                                        }, void 0, false, {
                                            fileName: "[project]/app/product/layout.tsx",
                                            lineNumber: 26,
                                            columnNumber: 13
                                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 23,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-gray-600",
                                    children: [
                                        "Variety: ",
                                        viewProduct.variety
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 30,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-gray-600",
                                    children: [
                                        "Category: ",
                                        viewProduct.category
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 31,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-lg font-bold mt-1",
                                    children: viewProduct.rate
                                }, void 0, false, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 32,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 22,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 14,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "mt-4",
                    children: [
                        /*#__PURE__*/ _jsxDEV("h3", {
                            className: "font-semibold text-gray-800",
                            children: "About the product"
                        }, void 0, false, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 38,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-sm text-gray-600 mt-1",
                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                        }, void 0, false, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 39,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 37,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "mt-4",
                    children: [
                        /*#__PURE__*/ _jsxDEV("h3", {
                            className: "font-semibold text-gray-800",
                            children: "About the vendor"
                        }, void 0, false, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 47,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "flex items-center gap-3 mt-2 bg-gray-50 p-3 rounded-lg",
                            children: [
                                /*#__PURE__*/ _jsxDEV(Image, {
                                    src: viewProduct.vendorAvatar,
                                    alt: viewProduct.vendor,
                                    width: 50,
                                    height: 50,
                                    className: "w-12 h-12 rounded-full object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 49,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "flex flex-col",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("p", {
                                                    className: "font-medium",
                                                    children: viewProduct.vendor
                                                }, void 0, false, {
                                                    fileName: "[project]/app/product/layout.tsx",
                                                    lineNumber: 58,
                                                    columnNumber: 15
                                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "flex items-center gap-1 bg-gray-100 border px-2 py-0.5 rounded-full text-xs font-medium",
                                                    children: "⭐ 9.2"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/product/layout.tsx",
                                                    lineNumber: 60,
                                                    columnNumber: 15
                                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/product/layout.tsx",
                                            lineNumber: 57,
                                            columnNumber: 13
                                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            className: "text-xs text-gray-600",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "font-medium",
                                                    children: "Location –"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/product/layout.tsx",
                                                    lineNumber: 65,
                                                    columnNumber: 15
                                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                                " ",
                                                viewProduct.vendorLocation
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/product/layout.tsx",
                                            lineNumber: 64,
                                            columnNumber: 13
                                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 56,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 48,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 46,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "mt-4 bg-gray-50 p-4 rounded-xl relative",
                    children: [
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "flex justify-between items-center mb-2",
                            children: [
                                /*#__PURE__*/ _jsxDEV("h3", {
                                    className: "font-semibold text-gray-800",
                                    children: [
                                        "Nutritional Value",
                                        " ",
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "text-xs text-gray-500",
                                            children: "(per 1 cup / 165 gms)"
                                        }, void 0, false, {
                                            fileName: "[project]/app/product/layout.tsx",
                                            lineNumber: 77,
                                            columnNumber: 13
                                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 75,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: ()=>setOpenNutritionEdit(true),
                                    className: "text-blue-500 hover:text-blue-700",
                                    children: "✎"
                                }, void 0, false, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 80,
                                    columnNumber: 11
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 74,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        nutritionForm.map((item, idx)=>/*#__PURE__*/ _jsxDEV("p", {
                                className: "text-sm text-gray-700",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "font-medium",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/app/product/layout.tsx",
                                        lineNumber: 90,
                                        columnNumber: 13
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    " : ",
                                    item.value
                                ]
                            }, idx, true, {
                                fileName: "[project]/app/product/layout.tsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "mt-2 text-xs text-gray-500",
                            children: "Rich in antioxidants, hydrating & supports immunity"
                        }, void 0, false, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 94,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 73,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
            ]
        }, void 0, true, {
            fileName: "[project]/app/product/layout.tsx",
            lineNumber: 4,
            columnNumber: 5
        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
    }, void 0, false, {
        fileName: "[project]/app/product/layout.tsx",
        lineNumber: 3,
        columnNumber: 3
    }, /*TURBOPACK member replacement*/ __turbopack_context__.e);
}{}{
    openNutritionEdit && /*#__PURE__*/ _jsxDEV("div", {
        className: "fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50",
        children: /*#__PURE__*/ _jsxDEV("div", {
            className: "bg-white p-6 rounded-xl w-[400px] shadow-lg",
            children: [
                /*#__PURE__*/ _jsxDEV("h2", {
                    className: "text-lg font-semibold mb-4",
                    children: "Edit Nutritional Value"
                }, void 0, false, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 106,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "space-y-3",
                    children: nutritionForm.map((item, idx)=>/*#__PURE__*/ _jsxDEV("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ _jsxDEV("input", {
                                    type: "text",
                                    value: item.label,
                                    onChange: (e)=>{
                                        const newForm = [
                                            ...nutritionForm
                                        ];
                                        newForm[idx].label = e.target.value;
                                        setNutritionForm(newForm);
                                    },
                                    className: "border rounded px-2 py-1 w-1/3 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 111,
                                    columnNumber: 13
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                /*#__PURE__*/ _jsxDEV("input", {
                                    type: "text",
                                    value: item.value,
                                    onChange: (e)=>{
                                        const newForm = [
                                            ...nutritionForm
                                        ];
                                        newForm[idx].value = e.target.value;
                                        setNutritionForm(newForm);
                                    },
                                    className: "border rounded px-2 py-1 w-2/3 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/app/product/layout.tsx",
                                    lineNumber: 121,
                                    columnNumber: 13
                                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                            ]
                        }, idx, true, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 110,
                            columnNumber: 11
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e))
                }, void 0, false, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 108,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "flex justify-end gap-2 mt-4",
                    children: [
                        /*#__PURE__*/ _jsxDEV("button", {
                            onClick: ()=>setOpenNutritionEdit(false),
                            className: "px-3 py-1 bg-gray-200 rounded-md",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 137,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("button", {
                            onClick: ()=>setOpenNutritionEdit(false),
                            className: "px-3 py-1 bg-blue-500 text-white rounded-md",
                            children: "Save"
                        }, void 0, false, {
                            fileName: "[project]/app/product/layout.tsx",
                            lineNumber: 143,
                            columnNumber: 9
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/product/layout.tsx",
                    lineNumber: 136,
                    columnNumber: 7
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
            ]
        }, void 0, true, {
            fileName: "[project]/app/product/layout.tsx",
            lineNumber: 105,
            columnNumber: 5
        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
    }, void 0, false, {
        fileName: "[project]/app/product/layout.tsx",
        lineNumber: 104,
        columnNumber: 3
    }, /*TURBOPACK member replacement*/ __turbopack_context__.e);
}}),
];

//# sourceMappingURL=app_product_layout_tsx_1568ac86._.js.map