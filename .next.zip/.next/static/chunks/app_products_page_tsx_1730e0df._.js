(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_93e27a29._.js",
  "static/chunks/app_products_d8bf9ada._.js"
],
    source: "dynamic"
});
