(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bfe2dcc9._.js",
  "static/chunks/app_vendors_48c75c49._.js"
],
    source: "dynamic"
});
