(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_93e27a29._.js",
  "static/chunks/app_product_9a5b2801._.js"
],
    source: "dynamic"
});
