'use client';

import React from 'react';
import Image from 'next/image';

const Topbar = () => {
  const currentDate = new Date().toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div className="w-full flex justify-between items-center px-6 py-4 bg-gray-100 shadow-sm">
      {/* Left: Page Title */}
      <h1 className="text-2xl font-semibold text-gray-800">Products</h1>

      {/* Right: Date, Notification, Avatar */}
      <div className="flex items-center gap-5">
        {/* Current Date */}
        <span className="text-gray-700 text-sm font-medium">{currentDate}</span>

        {/* Notification Icon */}
        <button className="w-10 h-10 flex items-center justify-center rounded-full bg-white shadow hover:shadow-md transition">
          <Image src="/icon/icon.png" alt="Notifications" width={40} height={40} />
        </button>

        {/* Profile Avatar (Styled like screenshot) */}
        <div className="w-10 h-10 rounded-full overflow-hidden border border-gray-300 shadow-sm">
          <Image
            src="/about/about.jpg" 
            alt="User"
            width={40}
            height={40}
            className="object-cover w-full h-full"
          />
        </div>
      </div>
    </div>
  );
};

export default Topbar;
